//array of pointer
#include<stdio.h>
#include<stdlib.h>
int main()
{
	int *arr[3],i,j,colsize;
	printf("Enter the number of column\n");
	scanf("%d",&colsize);
	for(i=0;i<3;i++)
	{
		arr[i]=(int*)malloc(colsize*sizeof(int));
	}
	printf("Enter the elememts\n");
	for(i=0;i<3;i++)
	{
		for(j=0;j<colsize;j++)
		{
			scanf("%d",&arr[i][j]);
		}
	}
	printf("Base Address%u\n",&arr);
	printf("%u\t%u\t%u\t%u\t%u\n",arr+0,arr+1,arr+2,arr+3,arr+4);
	printf("%u%u\n",**(arr+0)+1,**(arr+1)) ;
	printf("Elements Are=\n");
	for(i=0;i<3;i++)
	{
		for(j=0;j<colsize;j++)
		{
			printf("%d\t",arr[i][j]);
			printf("%d\t",*(arr+i)+j);
		}
		printf("\n");
	}
		
}
