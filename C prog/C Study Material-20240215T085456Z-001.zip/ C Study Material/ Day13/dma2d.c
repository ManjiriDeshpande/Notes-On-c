#include<stdio.h>
#include<stdlib.h>
int main()
{
	int **p,rowsize,colsize,i,j;
	printf("Enter the rowsize\n");
	scanf("%d",&rowsize);
	printf("Enter the Colsize\n");
	scanf("%d",&colsize);
	p=(int**)malloc(sizeof(int*)*rowsize);//
	for(i=0;i<rowsize;i++)
	{
		p[i]=(int*)malloc(sizeof(int)*colsize);
	}
	printf("Enter the elememts\n");
	for(i=0;i<rowsize;i++)
	{
		for(j=0;j<colsize;j++)
		{
			scanf("%d",&p[i][j]);
		}
	}
	printf("Elements Are=\n");
	for(i=0;i<rowsize;i++)
	{
		for(j=0;j<colsize;j++)
		{
			printf("%d\t",p[i][j]);
			printf("%u\t",*(p+i)+j);
		}
		printf("\n");
	}
printf("%u\n",*p);	
 
	free(p);
			
printf("%u",*p);		
}

