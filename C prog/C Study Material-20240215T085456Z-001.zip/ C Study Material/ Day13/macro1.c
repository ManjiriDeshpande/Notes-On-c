#include<stdio.h>
//#define ADD 1+2
//#define PI 3.14
//#define START int main(){
//	#define END }
//
//
//START
//	float r=2.5;
//	printf("%d\n",ADD);
//	printf("%f",PI*r*r);
//printf("%c\n",ADD);
//END
#define MIN(a,b) (a<b)?printf("%d is minimum",a):printf("%d is minimum",b);
int main()
{
	//MIN(10,20);
	//MIN(10.22,5.6);
	MIN('A','B');
}
 

