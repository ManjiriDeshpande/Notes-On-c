#include<stdio.h>
int main()
{
	int num=20;
	int *ptr=&num;
//	ptr=&num;
int **p;//pointer  to pointer 
p=&ptr;
printf("%d\n",num);
printf("%d\n",&num);
printf("%d\n",ptr);
printf("%d\n",*ptr);
printf("%d\n",&ptr);
printf("%d\n",p);
printf("%d\n",*p);
printf("%d\n",**p);
printf("%d\n",&p);
}
