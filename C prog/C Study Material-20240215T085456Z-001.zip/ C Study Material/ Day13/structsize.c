
#include<stdio.h>
#pragma pack (1)
struct student
{
	char name[10];
	int rollno:2;
	//int *ptr;
	
}s1;
int main()
{
	printf("%d\n",sizeof(struct student));
	printf("%d\n",sizeof(s1));
	//printf("%d\n",sizeof(s1.rollno));
	
}


