#include<stdio.h>
#include<stdlib.h>
int main()
{
	FILE *fptr;
	char ch;
	char str[20];
//create & write content inside file fputc()
	fptr=fopen("myfile.txt","a");
	
	if(fptr==NULL)
	{
		printf("File doese not exist\n");
		exit(0);
	}
	else
	{
		printf("Enter text:\n");
		//ctrl+z to stop charcters
		while((ch=getchar())!=EOF)
		{
			fputc(ch,fptr);
		}
		
	}
	//----use of fgetc()
/*	fptr=fopen("myfile.txt","r");
	if(fptr==NULL)
	{
		printf("This file not exist\n");
	}
	else
	{
		while((ch=fgetc(fptr))!=EOF)
		printf("%c",ch);
	}*/
/*fptr=fopen("file1.txt","w")	;
printf("Enter the text");
//to stop typing press ctrl+z
while(gets(str)!=NULL)
{
	fputs(str,fptr);
}*/
fclose(fptr);	
}
