#include<stdio.h>
/*int main()
{
	//const int a=10;//valid
//	a=10;//invalid assignment.
	//int b=a;//valid
	//a++;//invalid for constant variable
	int num=20;
	int num2=20;
	  //int *const ptr=&num;//address become constant
	  //const int *ptr=&num //value is pointed ptr is const
	  const int *const ptr=&num;
	  //ptr=&num2;
	  
	//ptr++;
	 (*ptr)++;
	printf("%d\n",*ptr);
	printf("%d\n",num);
}*/
/*int main()
{
	volatile int a=10;;
	//a=10;
	a++;
	printf("%d",a);
	
}*/
struct exmple
{
	unsigned int a;//bitfield
	//int b:4;//bitfield
	
}ex;
int main()
{
ex.a=2;
//ex.b=20;
printf("%u\n",ex.a);
printf("%d",sizeof(ex));
//printf("%d\n",ex.b);	
}
