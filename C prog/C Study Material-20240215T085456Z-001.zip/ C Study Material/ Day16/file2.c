#include<stdio.h>
#include<stdlib.h>
/*int main()
{
	FILE *fptr;
	char name[10];
	int rollno;
	fptr=fopen("file2.dat","w");//r -already file exists data read from file
	//w=writing data inside file & creating a file
	printf("Enter the name & roll no:\n");
	scanf("%s %d",name,&rollno);
	fprintf(fptr,"My name is %s and roll no is %d",name,rollno);
	fclose(fptr);
}*/
/*int main()
{
	FILE *fptr;
	 char name[10];
	int rollno;
	fptr=fopen("file2.dat","r");
	 
	 //printf("Name is\tRoll no\t\n");
	 while(fscanf(fptr,"%s%d",name,rollno)!=EOF)
	 printf("%s %d",name,rollno);
	fclose(fptr);
}*/
typedef struct student
{
	int rollno;
	char name[10];//array inside structure


}STUD;
int main()
{
	FILE *fptr;
	int i,n;
	STUD s;
	//fptr=fopen("stud.dat","w");
	fptr=fopen("student.dat","wb");
	printf("Enter number students record are inserted:-\n");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		printf("Enter the roll no:-\n");
		fflush(stdin);
		scanf("%d",&s.rollno);
		printf("Enter the name:-\n");
		getchar();
		//fflush(stdin);
		scanf("%s",s.name);
		//fprintf(fptr,"%d %s",s.rollno,s.name);
		fwrite(&s,sizeof(s),n,fptr);
		
	}
	//--------reading from file----------------------------------
	/*while(fread(&s,sizeof(s),n,fptr)==1)
	{
		printf("%s%d",s.name,s.rollno);
	}*/
	fclose(fptr);
}
//fwrite(&STUD,sizeof(STUD),5,fptr)
