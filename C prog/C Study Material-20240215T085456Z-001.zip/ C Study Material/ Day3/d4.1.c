#include<stdio.h>
int main()
{
	int a=6,b=7,c=9,d=4,e=5,f;
	char ch='d';
	//f=(c+d)||(a>b)&&(c==e);//ans=1
	//f=!((c+d)&&(a>b)||(c==e));
	//f=a&&b+c||e+d;
	//f=c&&b-c&&a+b||a==b;
//	f=ch+b&&ch-b||ch==100;
//	printf("Character is=%c\n ASCII value of =%d",ch,ch);
//	printf("%d",f);
	//printf("%d",ch==100);
//--------------------------------------------------------
//a++;//post increment op increment value by 1 a=a+1
//++a;//pre increment op increment value by 1;
//printf("%d",++a);
//f=--c;
//printf("%d\n",f);
//f=b--;
//printf("%d\n",f);
//printf("%d",b);
//--------------------------------------------------------
//d=d+2;
//d+=2;
////d-=3,a/=2,,d*=c
//printf("%d",d);
//----------------------------------------------
//f=10,20,30;
//printf("%d\n",f);
//f=(10,20,30);
//printf("%d\n",f);
f=(++e,++e);
printf("%d\n",f);
printf("%d\n",e);


}
