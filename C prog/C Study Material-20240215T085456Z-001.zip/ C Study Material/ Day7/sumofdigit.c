#include<stdio.h>
int main()
{
	int num,sum=0,d,temp;
	printf("enter the Number");
	scanf("%d",&num);
	//temp=num;
//	while(num>0)
//	{
//	d=num%10;
//	sum=sum+d;
//	num=num/10;	
//	}
for(;num>0;num=num/10)
{
	d=num%10;
	sum=sum+d;
}
	printf("Sum of digit=%d",sum);
}
