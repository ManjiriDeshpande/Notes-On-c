#include<stdio.h>
//int main()
//{
//	int i,j;
//	for(i=1;i<=5;i++)//outer
//	{
//		for(j=1;j<=i;j++)//inner
//		{
//			printf(" *");
//		}
//		printf("\n");
//	}
//}
int main()
{
	int i,j;
	 i=1;
	 while(i<=5)
		{
			j=1;
			while(j<=i)
			{
				printf(" *");
				j++;
			}
		printf("\n");
		i++;	
		}
		
		
	}

