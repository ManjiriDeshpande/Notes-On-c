#include<stdio.h>
//int main()
//{
//	int i;
//	for(i=1;i<=10;i++)
//	{
//		printf("%d\n",i);
//	}
//}
 
//int main()
//{
//	int i;
//	for(i=10;i>=1;i--)
//	{
//		printf("%d\n",i);
//	}
//}
//int main()
//{
//	int i;
//	for(i=2;i<=10;i=i+2)
//	{
//		printf("%d\n",i);
//	}
//}
//int main()
//{
//	int i=1;
//	for(;i<=10;)
//	{
//		printf("%d\n",i);
//		i++;
//	}
//}
//int main()
//{
//	int i=2;
//	for(; ;)
//	{
//		if(i<=10)		
//		 
//		{
//			printf("%d\n",i);
//		}
//		i=i+2;
//
//		
//	}
//}
//int main()
//{
//	int i;
//	for(i=1;i<=10;i++);
//	{
//		printf("%d\n",i);
//	}
//}
int main()
{
	int i,j;
	for(i=1,j=3;i<=3,j<=7;i++,j++)
	{
		printf("%d\t%d\n",i,j);
	}
}
