#include<stdio.h>
#include<stdlib.h>
//int main()
//{
//	int i;
//	for(i=1;i<=10;i++)
//	{
//		if(i==6)
//		{
//		//	printf("%d\n",i);
//			//break;
//			//continue;
//			//exit(1);
//			//printf("End");
//		}
//		printf("End");
//		printf("%d\n",i);
//	}
//}
int main()
{
	int i;
	printf("Enter the number");
	scanf("%d",&i);
	if(i==6)
	{
		exit(0);
		printf("End program");
	}
	printf("End program");
}
