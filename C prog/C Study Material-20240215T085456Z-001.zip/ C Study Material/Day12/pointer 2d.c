#include<stdio.h>
int main()
{
	int arr[3][3]={10,20,30,40,50,60,70,80,90};
	int i,j;
	//ptr=arr;
	for(i=0;i<3;i++)
	{
		for(j=0;j<3;j++)
		{
			printf("%d\t",*(*(arr+i)+j));//3d pointer notation*(*(*(arr+i)+j)+k)
			//printf("%u\t",*(arr+i)+j);
			//printf("%u\t",(arr[i]+j));
			//printf("%u\t",*(arr+i)+j);
			
		}
		
		printf("\n");
	}
	printf("\n");
	//printf("%u\t",*(arr+0)+0);
//	printf("%u\t",*(arr+0)+1);
	printf("%d\t",*(*arr+1)+5);
	//printf("%d",(*arr+0)+0);
	//printf("%d\n",*((*arr+0)+3));
	//printf("%d",*(arr+2));
	 
}


