#include<stdio.h>
#include<stdlib.h>
int main()
{
	int num,*ptr,i;
	printf("How many elements do want create?\n");
	scanf("%d",&num);
	//ptr=(int *)malloc(num*sizeof(int));
	ptr=(int *)calloc(num,sizeof(int));
	printf("Enter the elements\n");
	for(i=0;i<num;i++)
	{
		scanf("%d",&ptr[i]);
	}
	printf("Elements are:-");
	for(i=0;i<num;i++)
	{
		printf("%d\t\n",ptr[i]);
		printf("%d\t\n",(ptr+i));
	}
	free(ptr);
	for(i=0;i<num;i++)
	{
		
		printf("%d\t\n",ptr[i]);
		//printf("%d\t\n",(ptr+i));
	}
}
