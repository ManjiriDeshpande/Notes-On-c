#include<stdio.h>
#include<stdlib.h>
int main()
{

int num,*ptr,i;
	printf("How many elements do want create?\n");
	scanf("%d",&num);
	ptr=(int *)malloc(num*sizeof(int));
	//ptr=(int *)calloc(num,sizeof(int));
	printf("Enter the elements\n");
	for(i=0;i<num;i++)
	{
		scanf("%d",&ptr[i]);
	}
	printf("Elements are:-");
	for(i=0;i<num;i++)
	{
		printf("%d\t\n",ptr[i]);
		printf("%d\t\n",(ptr+i));
	}
	printf("\n");
	ptr=realloc(ptr,(num+3)*sizeof(int));
	printf("enter elements again\n");
	for(i=num;i<num+3;i++)
	{
		scanf("%d",&ptr[i]);
	}
	for(i=0;i<num+3;i++)
	{
		printf("%d\t\n",ptr[i]);
		printf("%d\t\n",(ptr+i));
	}
}
