//#include <stdio.h>
//#include"Header.h"
//extern int a;
//int main1()
//{
//	int b, c = 20;
//	printf("Enter the value of b");
//	scanf_s("%d", &b);
//	b++;
//	c++;
//	printf(" a=%d\n", a);
//	printf("before block c=%d\n", c);
//	{
//		int c = 30;
//		printf("in block c=%d\n", c);
//		printf("in block b=%d\n", b);
//	}
//	printf("After block c=%d\n", c);
//	printf("After block b=%d", b);
//	display();
//}
//void display()
//{
//	printf(" a=%d\n", a);
//	//printf("%d", c);
//}