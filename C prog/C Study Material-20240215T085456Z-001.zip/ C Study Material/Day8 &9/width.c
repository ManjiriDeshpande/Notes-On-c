//%wd width 
#include<stdio.h>
int main()
{
	int num=10,num1,c,a,b;
	float fnum=9.56f;
		printf("Enter the number");
	scanf("%3d",&num1);
	scanf("%5d",&a);
	//printf("%d\n",c);	
	printf("%d\t%d\n",num1,a);
//printf("%5d",num);
//printf("%9.2f",fnum);
//	//printf("%3.9f",fnum);
//	//printf("%d",num1);
//	printf("%7s","India");
//	
//	
}
//int main()
//{
//	int a=144,b=20,c;
//	a++;
//	c=(printf("Sonu"))+b;
//	printf("%d",c);
//}
