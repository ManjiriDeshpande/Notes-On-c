#include<stdio.h>
int main()
{
	int num=10;
	int *ptr;
	ptr=&num;
	char *p;
	float *fptr;
	printf("%d\n",num);//10
	printf("%d\n",&num);//Address on num
	printf("%d\n",ptr);
	printf("%d\n",&ptr);
	printf("%d\n",*ptr);
	printf("%d\n",sizeof(ptr));
		printf("%d\n",sizeof(p));
}
