#include<stdio.h>
#include"Header.h"
extern int a;
int main()
{
	register int j=5;
	printf("%d", j);
	int b;
	static int c;
	//printf("%d\n", b);
	printf("%d\n", a);
	printf("%d\n", c);
}