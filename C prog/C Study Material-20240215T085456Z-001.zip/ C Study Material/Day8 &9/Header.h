void display();
void display1();
int a ;
static int n = 20;
