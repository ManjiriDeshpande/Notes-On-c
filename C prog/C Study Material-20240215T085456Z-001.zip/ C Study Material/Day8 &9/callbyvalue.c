#include<stdio.h>
//void swap(int,int);
void swap(int *,int *);
int main()
{
	int n1=10,n2=20;
	//swap(n1,n2);
	swap(&n1,&n2);
	printf("After swapping  in main()n1=%d n2=%d\n",n1,n2);
}
//void swap(int num1,int num2)
//{
//	int temp;
//	temp=num1;
//	num1=num2;
//	num2=temp;
//	printf("After swapping  in swap()num1=%d num2=%d\n",num1,num2);
//}
void swap(int *num1,int *num2)
{
	int temp;
	temp=*num1;
	*num1=*num2;
	*num2=temp;
	printf("After swapping  in swap()num1=%d num2=%d\n",*num1,*num2);
}
