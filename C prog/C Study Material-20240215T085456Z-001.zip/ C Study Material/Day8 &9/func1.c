#include<stdio.h>
void add(int,int);//function declaration
int sub();
void div();
int mul(int,int);
int main()
{
	int n1=10,n2=20,res;
	//add(n1,n2);//function call
//	res=sub();
//	printf("Sub=%d",res);
div();
//printf("%d",mul(n1,n2));//acutal
res=mul(5.9f,6.7f);
//res=mul('A','B');
printf("Mul=%d",res);

	//printf("return in main()");
	
}
//void add(int n1,int n2)//function defination//formal arg
//{
//	printf("%d",n1+n2);
//}
//int sub()
//{
//	int s1=20,s2=5,res;
//	return s1-s2;
//	//res=s1-s2;
////	return res,10,20;
//
//
//}
//void div()
//{
//	int num1=30,num2=6;
//	printf("Div=%d",num1/num2);
//}
int mul(int m1,int m2)
{
	int res=m1*m2;
	return res;
}


