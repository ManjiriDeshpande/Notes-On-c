#include<stdio.h>
#include"Header.h"
extern int n;
int main2()
{
	display1();
	display1();
	display1();


}
void display1()
{
	//static int b = 1;
	printf("%d", n++);
}
