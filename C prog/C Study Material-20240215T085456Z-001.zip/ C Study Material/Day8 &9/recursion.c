#include<stdio.h>
//int main()
//{
//	int fact=1,n,i;
//	printf("Enter the number");
//	scanf("%d",&n);
//	for(i=1;i<=n;i++)
//	{
//		fact=fact*i;
//		
//	}
//	printf("Factorial is=%d",fact);
//}
int fact(int);
int main()
{
	int n;
	printf("Enter the number");
 scanf("%d",&n);
 printf("Factorial is=%d",fact(n));
}
int fact(int n)
{
	if(n==0)
	return 1;
	else
	return(n*fact(n-1));
}
