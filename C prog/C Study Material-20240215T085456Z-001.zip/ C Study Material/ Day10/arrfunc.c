#include<stdio.h>
//void display(int []);
//void accept(int *);
//int main()
//{
//	int arr[5];
//	accept(arr);
//	display(arr);
//	
//	
//	
//}
//void accept(int *a)
//{
//	int i;
//	printf("Enter the elements in an array");
//	for(i=0;i<5;i++)
//	{
//		scanf("%d",(a+i));
//	}
//}
//void display(int a[])
//{
//	int i;
//	for(i=0;i<5;i++)
//	{
//		printf("Arr[%d]=%d\t",i,a[i]);
//	}
//}
//-----------------------------------------
void display(int);
void accept(int);
int main()
{
	int arr[5];
	accept(arr[0]);
	//display(arr[0]);
	
	
	
}
void accept(int a)
{
	//int i;
	printf("Enter the element");
	 scanf("%d",&a);
	 display(a);
}
void display(int a)
{
	//int i;
	printf("%d",a);
	 
}
