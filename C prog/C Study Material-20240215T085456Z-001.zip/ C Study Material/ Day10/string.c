#include<stdio.h>
int main()
{
	char name[20];
	int i;
	printf("Enter the name");
for(i=0;i<20;i++)
//getc(name[i]);not allowed
//scanf("%c",&name[i]);
name[i]='\0';
//scanf("%s",name);
//printf("%s",name);
//gets(name);
//printf("Name=%s",name);an
//puts(name);
	
	
}
