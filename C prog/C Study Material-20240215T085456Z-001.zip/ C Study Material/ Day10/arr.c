#include<stdio.h>
/*int main()
{
	//int marks[5]={};
	//int marks[5]={10,20};
	int marks[]={10,20,30,50,60};
//int marks[];not allowed
//int marks[5];
int arr[5];
char ch[10];
//arr=marks;//you can not change base address
//marks++;//not allowed
arr[0]=marks[0];
	int i;
	printf("Enter the elements in array");
	
//	for(i=0;i<5;i++)
//	{
//		scanf("%d",&marks[i]);
//		//printf("Marks[%d]=%d",i,marks[i]);
//	}
//	for(i=0;i<5;i++)
//	{
//		printf("Marks[%d]=%d",i,marks[i]);
//	}
//pointer notation
//for(i=0;i<5;i++)
//	{
//		scanf("%d",marks+i);
//		 
//	}
for(i=0;i<5;i++)
	{
		printf("Marks[%d]=%d\tAddress of elements=%u\n",i,*(marks+i),(marks+i));
	}
	//printf("Base address=%u",marks);
	//printf("Size of int array=%d\n",sizeof(marks));
	//printf("size of char array=%d",sizeof(ch));
}*/
//--------------Pointer Arithmatic------------------------
int main()
{
	int arr[]={10,20,30,40,50};
	int *p1,*p2;
	p1=arr;
	printf("%d\n",arr);
	printf("%d\n",p1);
	printf("%d\n",&p1);
	printf("%d\n",*p1);
	p1++;
	printf("%d\n",*p1);
	p1++;
	printf("%d\n",*p1);
	p1--;
	printf("%d\n",*p1);
	//printf("%d",arr+1);
	//printf("%d\n",(*p1+1));
	p1++;
//	printf("%d",(*arr+1));
	p2=p1;
//	printf("%d\n",*p2);
	p2=arr;
	//printf("%d\n",*p2);
	int n=p1-p2;
	printf("%d",n);
	
	
	
}

