#include<stdio.h>
//int main()
//{
//	char ch;
//	printf("Enter a Character");
//	scanf("%c",&ch);
//	switch(ch)
//	{
//		    default:
//				printf("Consonanat");
//				break;
//			case 'a':
//			printf("vowel");
//			//break;
//			case 'e':
//			printf("vowel");
//			break;
//			case 'i':
//			printf("vowel");
//			break;
//			case 'o':
//			printf("vowel");
//			break;
//			case 'u':
//			printf("vowel");
//			break;
//			
//			
//	}
//}
//---------------------------------------------------------------------
//int main()
//{
//	char ch;
//	printf("Enter a Character");
//	scanf("%c",&ch);
//	switch(ch)
//	{
//		    
//			case 'a':	 
//			case 'e': 
//			case 'i':
//			case 'o': 
//			case 'u':
//				case 'A':
//					case 'E':
//			printf("vowel");
//			break;
//			default:
//				printf("Consonanat");
//			
//			
//			
//	}
//}
//---------------------------------------------
int main()
{
	int n1,n2,x, y;
	char ch;
	printf("Enter the n1 & n2");
	scanf("%d%d",&n1,&n2);
	printf("Press + for Add\n");
	printf("Press - for Sub\n");
	printf("Press * for Mul\n");
	printf("Press / for Div\n");
	scanf(" %c",&ch);
	switch(ch)
	{
		case '+':
			printf("Addition is=%d",n1+n2);
			break;
			case '-':
			printf("Subtraction is=%d",n1-n2);
			break;
			case '*':
			printf("Multiplication is=%d",n1*n2);
			break;
			case '/':
			printf("Division is=%d",n1/n2);
			break;
			default:
				printf("Invalid choice");
	}
}

