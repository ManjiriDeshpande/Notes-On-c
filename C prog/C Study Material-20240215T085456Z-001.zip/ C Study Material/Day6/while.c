#include<stdio.h>
int main()
{
	int i;
	i=1;//intliazation
	while(i<=10)//condition
	{
		printf("%d\n",i);
		i++;
	}
	printf(" after loop=%d",i);
}
