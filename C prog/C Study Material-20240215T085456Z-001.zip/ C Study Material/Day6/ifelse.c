#include<stdio.h>
int main()
{
	int m1,m2,m3,m4,m5,total;
	float per;
	printf("Enter the 5 subject marks");
	scanf("%d%d%d%d%d",&m1,&m2,&m3,&m4,&m5);
	total=m1+m2+m3+m4+m5;
	per=(float)total/5;
	printf("Total=%d \n Percentage=%f",total,per);
	if(per>=90)
	{
		printf("A+grd");
	}
	else if(per<90 && per>=80)
	{
		printf("A grd");
		
	}
	else if(per<80 && per>=70)
	{
		printf("B grd");
	}
	else if(per<70 && per>=60)
	{
		printf("C grd");
	}
	else if(per<60 && per>=35)
	{
			printf("Pass grd");
	}
	else{
		printf("Fail");
	}
}
