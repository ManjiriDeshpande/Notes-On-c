#include<stdio.h>
int main()
{
	int n1,n2,n3;
	printf("Enter the value of n1,n2,n3:-");
	scanf("%d%d%d",&n1,&n2,&n3);
	if(n1>n2)
	{
		if(n1>n3)
		{
			printf("%d is maxmium number",n1);
		
		}
		else{
			printf("%d is maxmium number",n3);
		}
	}
	else
	{
		if(n2>n3)
		{
				printf("%d is maxmium number",n2);
		}
		else{
			printf("n3=%d is maxmium number",n3);
		}
			
		
	}
}
