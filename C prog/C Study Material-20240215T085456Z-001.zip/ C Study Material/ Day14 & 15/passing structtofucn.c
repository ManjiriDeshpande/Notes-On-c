#include<stdio.h>
//typedef struct student
//{
//	int rollno;
//	char name[10];//array inside structure
//
//}STUD;
//void display(STUD *);
//int main()
//{
//	STUD s;
//	printf("Enter the roll no:-");
//	scanf("%d",&s.rollno);
//	getchar();
//	printf("Enter the name:-");
//	gets(s.name);
//	display(&s);
//}
//void display(STUD *s1)
//{
//	printf("Roll no is=%d\n Name of student=%s\n",s1->rollno,s1->name);
//}
 
