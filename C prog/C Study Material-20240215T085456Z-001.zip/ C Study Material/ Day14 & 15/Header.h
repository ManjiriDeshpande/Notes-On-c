#pragma pack (-1)
struct student
{
	
	int rollno;
	double d;
	char name;
	//int s;
	
	//float per;
	
}s1;
