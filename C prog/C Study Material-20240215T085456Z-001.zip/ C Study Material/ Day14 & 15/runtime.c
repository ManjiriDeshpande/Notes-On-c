#include<stdio.h>
//int main()
//{
//	int n1=10,n2;
//	printf("enter denominator=");
//	scanf("%d",&n2);
//	printf("%d",n1/n2);
//}
int main()
{
	int x=20,y=35;
	 x=y++ + x++;
	 printf("%d\t%d",x,y);
	 y=++y + ++x;
	 printf("%d\t%d",x,y);
	 //printf("x=%d\n y=%d",x,y);
}
