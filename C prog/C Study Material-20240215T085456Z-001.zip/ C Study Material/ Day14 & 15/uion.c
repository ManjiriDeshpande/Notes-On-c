#include<stdio.h>
union student
{
	int rollno[20];
	//double per;
};
int main()
{
	union student s;
//	printf("enter the roll no=\n");
//    scanf("%d",&s.rollno);
//    printf("Enter the percentage:-");
//     scanf("%lf",&s.per);
//     printf("Roll no=%d\n, Percentage=%lf\n",s.rollno,s.per);
     printf("%d",sizeof(s));
}

