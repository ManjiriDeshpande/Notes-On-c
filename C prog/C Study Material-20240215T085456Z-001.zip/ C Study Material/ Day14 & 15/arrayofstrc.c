#include<stdio.h>
typedef struct Customer
{
	int custid;
	char custname[10];
	float bill;
}cust;
int main()
{
	 cust c1[2];//Array of structure
	 cust *c3;//pointer to array of structure
	 c3=c1;
	 int i;
	 for(i=0;i<2;i++)
	 {
	 
	printf("Enter the custid");
	scanf("%d",&c1[i].custid);
	getchar();
	printf("Enter customer Name:-");
	gets(c1[i].custname);
	printf("Enter the bill");
	scanf("%f",&c1[i].bill);
}
for(i=0;i<2;i++)
{
	printf("Customer id=%d\n Cust Name=%s\nBill=%f",c3[i].custid,c3[i].custname,c3[i].bill);
	//printf("Customer id=%d\n Cust Name=%s\nBill=%f",c1[i].custid,c1[i].custname,c1[i].bill);
}
}

