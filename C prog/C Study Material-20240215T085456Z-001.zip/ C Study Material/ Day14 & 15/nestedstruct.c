#include<stdio.h>
struct Date
{
	int dd,mm,yy;

};
typedef struct Customer
{
	int custid;
	char custname[10];
	float bill;
	struct Date dob;//nested structure
}cust;
int main()
{
cust c1;
printf("Enter the custid");
	scanf("%d",&c1.custid);
	getchar();
	printf("Enter customer Name:-");
	gets(c1.custname);
	printf("Enter the bill");
	scanf("%f",&c1.bill);
	printf("Enter date of birth:-");
	scanf("%d%d%d",&c1.dob.dd,&c1.dob.mm,&c1.dob.yy);
	printf("Customer id=%d\n Cust Name=%s\nBill=%f\n",c1.custid,c1.custname,c1.bill);
	printf("\nDate of birth=%d/%d/%d",c1.dob.dd,c1.dob.mm,c1.dob.yy);
}
