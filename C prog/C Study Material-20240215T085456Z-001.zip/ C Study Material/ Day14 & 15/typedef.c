//---------------typedef------------------
#include<stdio.h>
typedef struct Customer
{
	int custid;
	char custname[10];
	float bill;
}cust;
int main()
{
	cust *c3;//pointer to structure
	cust c1,c2;
	c3=&c1;
	printf("Enter the custid");
	scanf("%d",&c1.custid);
	getchar();
	printf("Enter customer Name:-");
	gets(c1.custname);
	printf("Enter the bill");
	scanf("%f",&c1.bill);
	printf("Customer id=%d\n Cust Name=%s\nBill=%f",c3->custid,c3->custname,c3->bill);
