#include<stdio.h>
#include<stdlib.h>
typedef struct student
{
	int rollno;
	char name[10];//array inside structure


}STUD;
int main()
{
	STUD *s;
	int num,i;
	printf("Enter number students do you want create:-");
	scanf("%d",&num);
	s=(STUD*)malloc(sizeof(STUD)*num);
	for(i=0;i<num;i++)
	{
	printf("Enter the roll no:-");
	scanf("%d",&s[i].rollno);
	getchar();
	printf("Enter the name:-");
	gets(s[i].name);	
	}
 
	for(i=0;i<num;i++)
	{
		printf("Roll no is=%d\n Name of student=%s\n",s[i].rollno,s[i].name);
	}
}
