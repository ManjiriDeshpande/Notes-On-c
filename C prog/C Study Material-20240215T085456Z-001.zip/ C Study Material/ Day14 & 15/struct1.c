#pragma pack 1
#include<stdio.h>
#include"Header.h"
int main()
{
	struct student s2;
	
	/*printf("Enter the Roll number:-");
	scanf_s("%d", &s2.rollno);
	printf("Enter the percentage:-");
	scanf_s("%f", &s2.per);
	getchar();
	printf("Enter the name:-");
	gets(s2.name);*/
	
	//printf("Rollno:-%d\n Name=%s\nPercentage=%f\n", s2.rollno, s2.name, s2.per);
	printf("%d", sizeof(s1));
	//printf("Rollno:-%d\n Name=%s\nPercentage=%f\n", s1.rollno, s1.name, s1.per);
}