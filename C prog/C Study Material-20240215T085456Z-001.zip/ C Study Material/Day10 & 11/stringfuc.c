#include<stdio.h>
#include<string.h>
int main()
{
	char str1[20], str2[30];
	int c,n;
//	puts("Enter the string1");
//	gets(str1);
//	//puts(str1);
//	//puts("String1=",str1);//not allowed
//	puts("Enter the string2");
//	gets(str2);
//	//scanf("%s",str2);
//	printf("String1 is=%s\n",str1);
//	printf("String2 is=%s\n",str2);
	//----------strlen-----------------------------
//	c=strlen(str1);
//	printf("Length=%d\n",c);
	printf("Lenght of string=%d",strlen("Manjiri\0"));
	//printf("%d",sizeof("IACSD\0"));
	//-------------strcpy--------------------
	strcpy(str1,str2)
//	printf("Copied String=%s\n",strcpy(str1,str2));
//	printf("After CopyString1 is=%s\n",str1);
//	printf("After Copy String2 is=%s\n",str2);
//------------strcat()-----------------------
//printf("Concate String=%s\n",strcat(str1,str2));
//	printf("After concat String1 is=%s\n",str1);
//	printf("After concat String2 is=%s\n",str2);
//---------------strcmp-------------------------
//if str1 > str2 =result 1 checking character by character
//if str1<str2=-1
//str1==str2=0
//n=strcmp("Apple","Zoo");
//printf("%d",n);
//n=strcmp("Zoo","App");
//printf("%d",n);
//n=strcmp("App","app");
//printf("%d",n);
//n=strcmp("Appl","App");
//printf("%d",n);
//n=strcmp("App","App");
//printf("%d",n);
n=strcmp("App","APp");
printf("%d",n);

}
