#include<stdio.h>
int main()
{
	int stu[3][3],i,j;
	int stu1[3][2]={{1,555},{2,456},{3,432}};//{}
	//int stu1[3][2]={1,555,2,456,3,432};
	//int stu1[][2]={{2,456},{3,432}};
	//int stu1[][2]; not allwed without intilalization
//	printf("Enter the element in 3*3 array");
//	for(i=0;i<3;i++)
//	{
//		for(j=0;j<3;j++)
//		{
//			scanf("%d",&stu[i][j]);
//		}
//	}
//	for(i=0;i<3;i++)
//	{
//		for(j=0;j<3;j++)
//		{
//			printf("%d\t",stu[i][j]);
//			printf("%d\t",&stu[i][j]);
//		}
//		printf("\n");
//	}
	for(i=0;i<3;i++)
	{
		for(j=0;j<2;j++)
		{
			printf("%d\t",stu1[i][j]);
			//printf("%d\t",&stu1[i][j]);
		}
		printf("\n");
	}
	
	
}
