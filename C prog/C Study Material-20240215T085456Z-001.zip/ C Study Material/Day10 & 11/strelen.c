//user defined strelen()
#include<stdio.h>
//int sstrelen(char *)
int sstrlen(char []);
int main()
{
	char str1[10]="IACSD CDAC";
	int c;
	c=sstrlen(str1);
	printf("Length=%d",c);
}
//int sstrelen(char *s)
int sstrlen(char s[])
{
	int i=0,len=0;   //0   1   2   3  4
	while(s[i]!='\0')//I  A   C   S  D   \0//*s!='\0'
	{
		i++;
		len++;
	}
	return len;
}
