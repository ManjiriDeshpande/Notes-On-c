#include<stdio.h>
#include<string.h>
int main()
{
	char name[20]="IACSD";
	char word[10]="CDAC";
	char *s=name;
	//word=name;
	int i;
	//printf("Enter the name");
//for(i=0;i<20;i++)
//getc(name[i]);not allowed
//scanf("%c",&name[i]);
//name[i]='\0';
//scanf("%s",name);
//printf("%s",name);
//gets(name);
//printf("Name=%s",name);an
//puts(name);
//printf("%s",s);
int c=strlen(s);
for(i=0;i<c;i++)
{
printf("%c%c\n",*(s+0),i[s]);	
}

	
	
}
