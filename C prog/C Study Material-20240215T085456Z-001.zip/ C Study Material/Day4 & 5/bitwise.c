#include<stdio.h>
int main()
{
	int n=10,a=5 ,b=2;
	printf("%d\n",n<<2);
	printf("%d\n",n>>2);
	printf("%d",n&b);
}
