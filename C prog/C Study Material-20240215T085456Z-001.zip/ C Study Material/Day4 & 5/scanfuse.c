#include<stdio.h>
//int main()
//{
//	int num,num1,r;
//	r=printf("Enter the number\n");
//	r=scanf("%d%d",&num,&num1);
//	printf("number is %d\n",num);
//	printf("r is %d",r);
//}
//---------------------------
int main()
{
	char a;
	printf("Enter the letter");
	//getch(a);
	//getche(a);
	//getchar();
	//a=getch();
	//a=getche();
	a=getchar();
	printf("%c",a);
}
