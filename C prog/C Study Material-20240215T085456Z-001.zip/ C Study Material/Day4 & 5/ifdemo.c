#include<stdio.h>
int main()
{
	int num.s;
	printf("Enter the number");
	scanf("%d",&num);
//	if(num>0)
//	{	printf("%d is a +ve number",num);
// printf("%d is a +ve number",num);
//}
//	else
//	{
//	printf("%d is a -ve number",num);	
//	}
(num>0)?printf("%d is a +ve number",num):printf("%d is a -ve number",num);

}
